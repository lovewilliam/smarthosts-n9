<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Header</name>
    <message>
        <location filename="../qml/Header.qml" line="6"/>
        <source>SmartHosts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainPage</name>
    <message>
        <location filename="../qml/MainPage.qml" line="29"/>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="46"/>
        <location filename="../qml/MainPage.qml" line="55"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="57"/>
        <location filename="../qml/MainPage.qml" line="198"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="63"/>
        <source>Done !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="64"/>
        <source>Changes has been made to
 hosts file !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="72"/>
        <location filename="../qml/MainPage.qml" line="94"/>
        <source>LastUpdate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="73"/>
        <location filename="../qml/MainPage.qml" line="107"/>
        <source>Hosts File Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="174"/>
        <source>Add to hosts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="196"/>
        <source>About smarthosts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="197"/>
        <source>smarthosts by
lovewilliam&lt;lovewilliam@gmail.com&gt;
http://code.google.com/p/smarthosts-n9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="228"/>
        <source>&lt;center&gt;contacting server...&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="294"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="303"/>
        <source>Revert to clean hosts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="312"/>
        <source>Check Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="321"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../qml/Settings.qml" line="14"/>
        <source>Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Settings.qml" line="37"/>
        <source>Select Hosts File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Settings.qml" line="46"/>
        <source>PC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Settings.qml" line="52"/>
        <source>Android</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Settings.qml" line="58"/>
        <source>IOS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Settings.qml" line="68"/>
        <source>&lt;font color=&quot;red&quot;&gt;Don&apos;t forget to check update 
 after selecting new hosts file.&lt;/font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../qml/main.qml" line="30"/>
        <source>Network error : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="33"/>
        <source>Filesys error : </source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
