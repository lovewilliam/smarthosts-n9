#!/bin/sh

lupdate ../qml/*qml -ts smarthosts.ts
lrelease smarthosts_zh.ts


