<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>Header</name>
    <message>
        <location filename="../qml/Header.qml" line="6"/>
        <source>SmartHosts</source>
        <translation>SmartHosts</translation>
    </message>
</context>
<context>
    <name>MainPage</name>
    <message>
        <location filename="../qml/MainPage.qml" line="29"/>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="46"/>
        <location filename="../qml/MainPage.qml" line="55"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="57"/>
        <source>OK</source>
        <translation>好</translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="63"/>
        <source>Done !</source>
        <translation>完成！</translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="64"/>
        <source>Changes has been made to
 hosts file !</source>
        <translation>更改已写入
 hosts 文件！</translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="86"/>
        <source>LastUpdate:</source>
        <translation>上次更新：</translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="99"/>
        <source>Hosts File Date:</source>
        <translation type="unfinished">Hosts 文件日期：</translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="166"/>
        <source>Add to hosts</source>
        <translation>添加到 Hosts</translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="220"/>
        <source>&lt;center&gt;contacting server...&lt;/center&gt;</source>
        <translation>&lt;center&gt;正在联系服务器...&lt;/center&gt;</translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="286"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="295"/>
        <source>Revert to clean hosts</source>
        <translation>还原系统默认Hosts</translation>
    </message>
    <message>
        <location filename="../qml/MainPage.qml" line="304"/>
        <source>Check Update</source>
        <translation>检查更新</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../qml/main.qml" line="30"/>
        <source>Network error : </source>
        <translation>网络错误：</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="33"/>
        <source>Filesys error : </source>
        <translation>文件系统错误：</translation>
    </message>
</context>
</TS>
